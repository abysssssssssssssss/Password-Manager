import sqlite3

def creategeneratedpasswordlistdatabase():
    conn = sqlite3.connect('generatedpasswordlist.db')

    c = conn.cursor()

    c.execute('''CREATE TABLE if not exists generatedpasswordlist(
            generatedpassword text
            )''')

    conn.commit()

    conn.close()

