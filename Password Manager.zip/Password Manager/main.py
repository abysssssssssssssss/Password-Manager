from tkinter import *
from tkinter import messagebox
import sqlite3
import tkinter as tk
from tkinter import ttk
from passwordgenerator import generator
from generatedpassworddatabase import creategeneratedpasswordlistdatabase
from databasecreate import createpasswordlistdatabase

root = tk.Tk()
root.title('Memento')

screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
root.geometry(f"{screen_width}x{screen_height}")

root.grid_columnconfigure(0, weight=1)
root.grid_columnconfigure(1, weight=0)

root.grid_rowconfigure(0, weight=0)
root.grid_rowconfigure(0, weight=0)


global wordcount 
global numbercount 
global symbolcount
global has_favoriteword 

#Clears mainframe
def clear_mainframe():
   for widgets in Mainframe.winfo_children():
      widgets.destroy()

def passwordlistquery():
    conn = sqlite3.connect('passwordlist.db')

    c = conn.cursor()

    c.execute("SELECT rowid, * FROM passwordlist")

    global records
    records = c.fetchall()

    global count
    count = 0
    for record in records:
        if count % 2 == 0:
            
            pmmy_tree.insert(parent='', index = "end", iid=count, text="", values = (record[0], record[1], record[2], record [3]), tags = ("evenrow"))
        else:
            
            pmmy_tree.insert(parent='', index = "end", iid=count, text="", values = (record[0], record[1], record[2], record [3]), tags = ("oddrow"))

        count += 1
    conn.commit()

    conn.close()

def generatedpasswordquery():
    conn = sqlite3.connect('generatedpasswordlist.db')

    c = conn.cursor()

    c.execute("SELECT rowid, * FROM generatedpasswordlist")

    global records
    records = c.fetchall()

    global count
    count = 0
    for record in records:
        if count % 2 == 0:
            pgmy_tree.insert(parent='', index = "end", iid=count, text="", values = (record[0], record[1]), tags = ("evenrow"))
            
        else:
            pgmy_tree.insert(parent='', index = "end", iid=count, text="", values = (record[0], record[1]), tags = ("oddrow"))
        

        count += 1
    conn.commit()

    conn.close()

def homepage():
    homepage = tk.Frame(Mainframe)

    createpasswordlistdatabase()
    creategeneratedpasswordlistdatabase()

    file = open('homepagetext.txt', 'r', encoding="UTF8").read()

    homepagetitle = Label(homepage, text = "Memento")
    homepagetitle.config(font = ('Arial',  20))
    homepagetext = Label(homepage, text = file, justify="left", wraplength = 1000)

    homepagetitle.grid(row = 0, column = 0, padx=(20, 0), pady=(15, 0), sticky = W)
    homepagetext.grid(row = 1, column = 0, padx=(20, 0), pady=(15, 0), sticky = W)

    homepage.grid(row = 0, column = 0, sticky="nsew")

def helppage():
    clear_mainframe()
    helppage = tk.Frame(Mainframe)

    
    my_canvas = Canvas(helppage, width=1050, height=640)
    my_canvas.pack(side = "left", fill = BOTH, expand = 1)

    my_scrollbar = ttk.Scrollbar(helppage, orient=VERTICAL, command = my_canvas.yview)
    my_scrollbar.pack(side = "right", fill = Y)

    my_canvas.configure(yscrollcommand=my_scrollbar.set)
    my_canvas.bind('<Configure>', lambda e : my_canvas.configure(scrollregion = my_canvas.bbox("all")))

    placeholderframe = Frame(my_canvas)

    my_canvas.create_window((0,0), window = placeholderframe, anchor = "nw")

    
    file = open('helppagetext.txt', 'r', encoding="UTF8").read()

    helppagetitle = Label(placeholderframe, text = "Help Page")
    helppagetitle.config(font = ('Arial',  20))
    helppagetext = Label(placeholderframe, text = file, justify="left")

    helppagetitle.grid(row = 0, column = 0, padx=(20, 0), pady=(15, 0), sticky = W)
    helppagetext.grid(row = 1, column = 0, padx=(20, 0), pady=(15, 0), sticky = W)

    helppage.grid(row = 0, column = 0, sticky="nsew")


def pgpage():
    clear_mainframe()
    pgframe = tk.Frame(Mainframe)

    pgframe.grid_columnconfigure(0, weight=0)
    pgframe.grid_columnconfigure(1, weight=0)

    pgframe.grid_rowconfigure(0, weight=0)
    pgframe.grid_rowconfigure(1, weight=0)

    inputpgframe = LabelFrame(pgframe, text = "Password Generator", padx = 10, pady = 10)
    inputpgframe.configure(height = 235, width = 1085)
    inputpgframe.grid_propagate(FALSE)
    inputpgframe.grid(row = 0, column = 0, padx=(20, 0), pady=(15, 0), sticky = W)

    outputpgframe = tk.Frame(pgframe, highlightbackground='black', highlightthickness=2, padx = 10, pady = 10)
    outputpgframe.configure(height = 400, width = 1085)
    outputpgframe.pack_propagate(False)
    outputpgframe.grid(row = 1, column = 0, padx=(20, 0), pady=(10, 0), sticky = W)
    
    def generatepassword():
        wordcount = wordcountentry.get()
        numbercount = numbercountentry.get()
        symbolcount = symbolcountentry.get()
        favoriteword = str(favoritewordentry.get())
        has_favoriteword = favoritewordyesnovalue.get()
        lb = 0
        ub = 15
        
        if wordcount and numbercount and symbolcount:
            if lb <= int(wordcount) <= ub and lb <= int(numbercount) <= ub and lb <= int(symbolcount) <= ub:

                gpassword = generator(int(wordcount), int(numbercount), int(symbolcount), has_favoriteword, favoriteword)

                conn = sqlite3.connect('generatedpasswordlist.db')

                c = conn.cursor()

                c.execute("INSERT INTO generatedpasswordlist VALUES(:generatedpassword)",
                        {
                            "generatedpassword" : gpassword,
                        }
                        
                        )

                conn.commit()

                conn.close()

                if deleteaftergeneratingyesnovalue.get() == 0:
                    pass
                else:
                    clearentry()


                pgmy_tree.delete(*pgmy_tree.get_children())

                generatedpasswordquery()
            else:
                messagebox.showwarning("Warning", "Please make all Counts 0 to 15 inclusively")
        else:
            messagebox.showwarning("Warning", "Please Fill in All Entry Boxes, with Favorite word being Optional")

    def clearoutputpgframe():

        for record in pgmy_tree.get_children():
                pgmy_tree.delete(record)

        conn = sqlite3.connect('generatedpasswordlist.db')

        c = conn.cursor()

        c.execute("DROP TABLE generatedpasswordlist")

        conn.commit()

        conn.close()
        
        creategeneratedpasswordlistdatabase()
        

    def clearentry():
        wordcountentry.delete(0, END)
        numbercountentry.delete(0, END)
        symbolcountentry.delete(0, END)
        favoritewordentry.delete(0, END)

    def selectrecord(e):

        selected = pgmy_tree.focus()

    def deleterow():

        tempdelete = 0

        tempdelete = pgmy_tree.selection()[0]
        pgmy_tree.delete(tempdelete)
        tempdelete = int(tempdelete) + 1

        conn = sqlite3.connect('generatedpasswordlist.db')

        c = conn.cursor()

        c.execute("DELETE from generatedpasswordlist WHERE oid =" + str(tempdelete))

        oids = c.execute("SELECT oid FROM generatedpasswordlist").fetchall()
        
        for i, row in enumerate(oids, start=1):
            c.execute("UPDATE generatedpasswordlist SET oid = ? WHERE oid = ?", (i, row[0]))  

        conn.commit()

        conn.close()

        pgmy_tree.delete(*pgmy_tree.get_children())

        generatedpasswordquery()

    def copy():
        tempcopied = pgmy_tree.focus()
        copiedpassword = pgmy_tree.item(tempcopied)["values"][1]
        root.clipboard_clear()
        root.clipboard_append(copiedpassword)

    def updatepreferences():
        newroot = Toplevel()
        newroot.title('Update Preferences')

        newroot.geometry(f"1100x200")

        def savechanges():

            wordcount = int(wordcountentry.get())
            numbercount = int(numbercountentry.get())
            symbolcount = int(symbolcountentry.get())
            favoriteword = str(favoritewordentry.get())
            has_favoriteword = favoritewordyesnovalue.get()
            temp = deleteaftergeneratingyesnovalue.get()

            file = open('preferences.txt', 'w')
            
            file.write( str(wordcount) + '\n' + str(numbercount) + '\n' + str(symbolcount)+ '\n' + str(has_favoriteword) + '\n'+ str(favoriteword) + '\n' + str(temp))
            

            file.close()
        
        
        Conditionsframe  = LabelFrame(newroot, text = "Conditions")
        Conditionsframe.configure(height = 110, width = 1050)
        Conditionsframe.grid_propagate(FALSE)

        wordcountlabel = Label(Conditionsframe, text = "Enter Wordcount")
        wordcountentry = Entry(Conditionsframe)

        numbercountlabel = Label(Conditionsframe, text = "Enter Numbercount")
        numbercountentry = Entry(Conditionsframe)

        symbolcountlabel = Label(Conditionsframe, text = "Enter Symbolcount")
        symbolcountentry = Entry(Conditionsframe)

        favoritewordyesnovalue = BooleanVar()
        favoritewordcheckbox = Checkbutton(Conditionsframe, text = "Use Favoriteword?", variable = favoritewordyesnovalue)
        favoritewordlabel = Label(Conditionsframe, text = "Enter your Favoriteword")
        favoritewordentry = Entry(Conditionsframe)

        deleteaftergeneratingyesnovalue = BooleanVar()
        deleleaftergeneratingcheckbox = Checkbutton(Conditionsframe, text = "Delete Entry Boxes after generating passwords?", variable = deleteaftergeneratingyesnovalue)

        savebutton = Button(newroot,text = "Save Changes", command = savechanges)

        Conditionsframe.grid(row = 0, column = 0, padx = 5, pady = 5, sticky = W)

        wordcountlabel.grid(row=2, column=0, padx=10, pady=10)
        wordcountentry.grid(row=2, column=1, padx=10, pady=10)

        numbercountlabel.grid(row=2, column=2, padx=10, pady=10)
        numbercountentry.grid(row=2, column=3, padx=10, pady=10)

        symbolcountlabel.grid(row=2, column=4, padx=10, pady=10)
        symbolcountentry.grid(row=2, column=5, padx=10, pady=10)

        favoritewordcheckbox.grid(row=3, column=0, padx=10, pady=10)
        favoritewordlabel.grid(row=3, column=1, padx=10, pady=10)
        favoritewordentry.grid(row=3, column=2, padx=10, pady=10)

        deleleaftergeneratingcheckbox.grid(row = 3, column = 3, padx=10, pady=10)

        savebutton.grid(row = 1, column = 0)

        file = open('preferences.txt', 'r')
        f = file.readlines()

        preferences = []
        for line in f:            
            preferences.append(line.strip())
            
        wordcountentry.insert(0, preferences[0])
        numbercountentry.insert(0, preferences[1])
        symbolcountentry.insert(0, preferences[2])
        favoritewordyesnovalue.set(preferences[3])
        favoritewordentry.insert(0, preferences[4])
        deleteaftergeneratingyesnovalue.set(preferences[5])

        file.close()

        


    def usepreferences():

        clearentry()

        file = open('preferences.txt', 'r')
        f = file.readlines()

        preferences = []
        for line in f:            
            preferences.append(line.strip())
            
        wordcountentry.insert(0, preferences[0])
        numbercountentry.insert(0, preferences[1])
        symbolcountentry.insert(0, preferences[2])
        favoritewordyesnovalue.set(preferences[3])
        favoritewordentry.insert(0, preferences[4])
        deleteaftergeneratingyesnovalue.set(preferences[5])

        file.close()

    global pgmy_tree

    style = ttk.Style()
    style.theme_use('default')

    style.configure("Treeview", background = "#D3D3D3", foreground = "black", rowheight = 35, fieldbackground = "#D3D3D3")

    style.map("Treeview", background = [("selected", "#347803")])

    pgtree_frame = Frame(outputpgframe)
    pgtree_frame.grid_propagate(FALSE)
    pgtree_frame.grid(row = 0, column = 0, sticky = NE)

    tree_scrollbar = Scrollbar(pgtree_frame)
    tree_scrollbar.pack(side = RIGHT, fill = Y)

    pgmy_tree = ttk.Treeview(pgtree_frame, yscrollcommand = tree_scrollbar.set, selectmode="extended")

    tree_scrollbar.config(command = pgmy_tree.yview)

    pgmy_tree['column'] = ("ID", "Generated Password")

    pgmy_tree.column("#0", width = 0, stretch=NO)
    pgmy_tree.column("ID", width = 30, anchor = W)
    pgmy_tree.column("Generated Password", width = 1011, anchor = W)

    pgmy_tree.heading("#0", text="")
    pgmy_tree.heading("ID", text = "ID", anchor = W)
    pgmy_tree.heading("Generated Password", text="Generated Password", anchor = W)

    pgmy_tree.tag_configure("oddrow", background = "white")
    pgmy_tree.tag_configure("evenrow", background = "lightblue")
    
    pgmy_tree.pack()

    generatedpasswordquery()

    pgmy_tree.bind("<ButtonRelease-1>", selectrecord)
        
    Conditionsframe  = LabelFrame(inputpgframe, text = "Conditions")
    Conditionsframe.configure(height = 110, width = 1050)
    Conditionsframe.grid_propagate(FALSE)

    global wordcountentry
    wordcountlabel = Label(Conditionsframe, text = "Enter Wordcount")
    wordcountentry = Entry(Conditionsframe)

    numbercountlabel = Label(Conditionsframe, text = "Enter Numbercount")
    numbercountentry = Entry(Conditionsframe)

    symbolcountlabel = Label(Conditionsframe, text = "Enter Symbolcount")
    symbolcountentry = Entry(Conditionsframe)

    favoritewordyesnovalue = BooleanVar()
    favoritewordcheckbox = Checkbutton(Conditionsframe, text = "Use Favoriteword?", variable = favoritewordyesnovalue)
    favoritewordlabel = Label(Conditionsframe, text = "Enter your Favoriteword")
    favoritewordentry = Entry(Conditionsframe)

    deleteaftergeneratingyesnovalue = BooleanVar()
    deleleaftergeneratingcheckbox = Checkbutton(Conditionsframe, text = "Delete Entry Boxes after generating passwords?", variable = deleteaftergeneratingyesnovalue)

    # commandgframe
    Commandsframe = LabelFrame(inputpgframe, text ="Commands")
    Commandsframe.configure(height = 71, width = 1050)
    Commandsframe.grid_propagate(FALSE)

    Clearpasswordbutton = Button(Commandsframe, text = "Clear generated passwords", command = clearoutputpgframe)
    Generatepassword = Button(Commandsframe, text="Generate Password", command=generatepassword)
    Clearentryboxes = Button(Commandsframe, text = "Clear Entry Boxes", command = clearentry)
    Copybutton = Button(Commandsframe, text = "Copy Selected Password", command = copy)
    Updatepreferencesbutton = Button(Commandsframe, text = "Update Preferences", command = updatepreferences)
    Usepreferencesbutton = Button(Commandsframe, text = "Use Preferences", command = usepreferences)
    Deleterowbutton = Button(Commandsframe,text = "Delete Row", command = deleterow)


    # grids

    Conditionsframe.grid(row = 1, column = 0, padx = 5, pady = 5, sticky = W)

    Commandsframe.grid(row = 2, column = 0, padx = 5, pady = 5, sticky = W)

    
    
    Clearpasswordbutton.grid(row = 0, column = 1, padx = 10, pady = 10)
    Generatepassword.grid(row=0, column=0, padx=10, pady=10)
    Clearentryboxes.grid(row = 0 , column = 2, padx = 10, pady = 10)
    Copybutton.grid(row = 0 , column = 3, padx = 10, pady = 10)
    Updatepreferencesbutton.grid(row = 0 , column = 4, padx = 10, pady = 10)
    Usepreferencesbutton.grid(row = 0, column = 5, padx = 10, pady = 10)
    Deleterowbutton.grid(row = 0, column = 6, padx = 10, pady = 10)

    wordcountlabel.grid(row=2, column=0, padx=10, pady=10)
    wordcountentry.grid(row=2, column=1, padx=10, pady=10)

    numbercountlabel.grid(row=2, column=2, padx=10, pady=10)
    numbercountentry.grid(row=2, column=3, padx=10, pady=10)

    symbolcountlabel.grid(row=2, column=4, padx=10, pady=10)
    symbolcountentry.grid(row=2, column=5, padx=10, pady=10)

    favoritewordcheckbox.grid(row=3, column=0, padx=10, pady=10)
    favoritewordlabel.grid(row=3, column=1, padx=10, pady=10)
    favoritewordentry.grid(row=3, column=2, padx=10, pady=10)

    deleleaftergeneratingcheckbox.grid(row = 3, column = 3, padx=10, pady=10)

    # Display pmframe within Mainframe
    
    pgframe.grid(row=0, column=0, sticky="nsew")


def pmpage():
    clear_mainframe()

    pmframe = tk.Frame(Mainframe)
    pmframe.configure(height = 700, width = 1125)

    def clearentry():
        identry.configure(state = "normal")
        identry.delete(0,END)
        identry.configure(state = "readonly")
        websiteentry.delete(0, END)
        emailentry.delete(0, END)
        passwordentry.delete(0, END)
        
    def selectrecord(e):
        clearentry()

        selected = pmmy_tree.focus()
        values = pmmy_tree.item(selected, "values")

        identry.configure(state = "normal")
        identry.insert(0, values[0])
        identry.configure(state = "readonly")
        websiteentry.insert(0, values[1])
        emailentry.insert(0, values[2])
        passwordentry.insert(0, values[3])

    def addrecord():
        websitentryyes = websiteentry.get()
        emailentryyes =emailentry.get()
        passwordtryyes = passwordentry.get()

        if websitentryyes and emailentryyes and passwordtryyes:
            conn = sqlite3.connect('passwordlist.db')

            c = conn.cursor()

            c.execute("INSERT INTO passwordlist VALUES(:website, :email, :password)", 
                    {
                        "website" : websiteentry.get(),
                        "email" : emailentry.get(),
                        "password" : passwordentry.get()
                    }
                    
                    )

            conn.commit()

            conn.close()

            clearentry()

            pmmy_tree.delete(*pmmy_tree.get_children())

            passwordlistquery()
        else:
            messagebox.showwarning("Warning", "Please Fill in All Entry Boxes")

    def moveup():
        rows = pmmy_tree.selection()
        for row in rows:
            pmmy_tree.move(row, pmmy_tree.parent(row), pmmy_tree.index(row)-1)

    def movedown():
        rows = pmmy_tree.selection()
        for row in reversed(rows):
            pmmy_tree.move(row, pmmy_tree.parent(row), pmmy_tree.index(row)+1)

    def deleterow():

        tempdelete = pmmy_tree.selection()[0]
        pmmy_tree.delete(tempdelete)

        conn = sqlite3.connect('passwordlist.db')

        c = conn.cursor()
        identry.configure(state = "normal")
        c.execute("DELETE from passwordlist WHERE oid =" + identry.get())
        identry.configure(state = "readonly")
        oids = c.execute("SELECT oid FROM passwordlist").fetchall()
        
        
        for i, row in enumerate(oids, start=1):
            c.execute("UPDATE passwordlist SET oid = ? WHERE oid = ?", (i, row[0]))
             

        conn.commit()

        conn.close()

        pmmy_tree.delete(*pmmy_tree.get_children())

        passwordlistquery()


    
    def deletemanyrecords():
        tempdeletes = pmmy_tree.selection()
        
        ids_to_delete = []
        for record in tempdeletes:
            ids_to_delete.append(pmmy_tree.item(record, 'values')[0])
            
        for record in tempdeletes:
            pmmy_tree.delete(record)

        conn = sqlite3.connect('passwordlist.db')

        c = conn.cursor()

        c.executemany("DELETE FROM passwordlist WHERE oid = ?", [(a,) for a in ids_to_delete])

        ids_to_delete = []

        oids = c.execute("SELECT oid FROM passwordlist").fetchall()
        
        
        for i, row in enumerate(oids, start=1):
            c.execute("UPDATE passwordlist SET oid = ? WHERE oid = ?", (i, row[0]))

        conn.commit()

        conn.close()
        
        pmmy_tree.delete(*pmmy_tree.get_children())

        passwordlistquery()

        clearentry()

	
    def updaterecord():
        selected = pmmy_tree.focus()
        identry.configure(state = "normal")
        pmmy_tree.item(selected, text = "", values = (identry.get(), websiteentry.get(), emailentry.get(), passwordentry.get()))
        identry.configure(state = "readonly")
        #sqlite3
        conn = sqlite3.connect('passwordlist.db')

        c = conn.cursor()
        identry.configure(state = "normal")

        c.execute('''UPDATE passwordlist SET
                  
                  website = :website,
                  email = :email,
                  password = :password
                  
                  WHERE oid = :oid''',
                  {
                      "website" : websiteentry.get(),
                      "email" : emailentry.get(),
                      "password" : passwordentry.get(),
                      "oid" : identry.get()
                  })
        identry.configure(state = "readonly")
        conn.commit()

        conn.close()

        clearentry()
        
        


    #treeviewer
        
    outputpmframe = tk.Frame(pmframe, highlightbackground='black', highlightthickness=2)
    outputpmframe.configure(height = 0, width = 0)
    outputpmframe.pack_propagate(False)
    outputpmframe.grid(row = 0, column = 2, padx=(5, 0), pady=(17, 0), sticky = NE)
    
    global pmmy_tree

    style = ttk.Style()
    style.theme_use('default')

    style.configure("Treeview", background = "#D3D3D3", foreground = "black", rowheight = 59, fieldbackground = "#D3D3D3")

    style.map("Treeview", background = [("selected", "#347803")])

    pmtree_frame = Frame(outputpmframe)
    pmtree_frame.grid_propagate(FALSE)
    pmtree_frame.grid(row = 0, column = 1, padx = 10, pady = 15, sticky = NE)

    tree_scrollbar = Scrollbar(pmtree_frame)
    tree_scrollbar.pack(side = RIGHT, fill = Y)

    pmmy_tree = ttk.Treeview(pmtree_frame, yscrollcommand = tree_scrollbar.set, selectmode="extended")

    tree_scrollbar.config(command = pmmy_tree.yview)

    pmmy_tree['column'] = ("ID", "Website", "Email", "Password")

    pmmy_tree.column("#0", width = 0, stretch=NO)
    pmmy_tree.column("ID", width = 30, anchor = W)
    pmmy_tree.column("Website", width = 255, anchor = W)
    pmmy_tree.column("Email", width = 255, anchor = W)
    pmmy_tree.column("Password", width = 255, anchor = W) 

    pmmy_tree.heading("#0", text="")
    pmmy_tree.heading("ID", text = "ID", anchor = W)
    pmmy_tree.heading("Website", text = "Website", anchor = W)
    pmmy_tree.heading("Email", text="Email", anchor = W)
    pmmy_tree.heading("Password", text="Password", anchor = W)

    pmmy_tree.tag_configure("oddrow", background = "white")
    pmmy_tree.tag_configure("evenrow", background = "lightblue")

    passwordlistquery()
    
    pmmy_tree.pack()
    

    pmoptions_frame = LabelFrame(pmframe, text="Password Manager")
    pmoptions_frame.configure(height = 650, width = 250)
    pmoptions_frame.grid_propagate(FALSE)
    pmoptions_frame.grid(row = 0, column = 0, padx = 10, pady = 10, sticky = NW)

    record_frame = LabelFrame(pmoptions_frame, text="Records")
    record_frame.configure(height = 240, width = 225)
    record_frame.grid_propagate(FALSE)
    record_frame.grid(row = 0, column = 0, padx = 10, pady = 10, sticky = W)

    identry = Entry(record_frame, state = "readonly")
    emailentry = Entry(record_frame)
    websiteentry = Entry(record_frame)
    passwordentry= Entry(record_frame)

    identry.grid(row = 1, column = 0, padx = 10, pady = 2)
    websiteentry.grid(row=3, column= 0, padx = 10, pady =2)
    emailentry.grid(row=5, column= 0, padx = 10, pady =2)
    passwordentry.grid(row=7, column= 0, padx = 10, pady =2)

    idlabel = Label(record_frame, text ="ID")
    websitelabel = Label(record_frame, text="Website")
    emaillabel = Label(record_frame, text="Email")
    passwordlabel = Label(record_frame, text="Password")

    idlabel.grid(row=0, column=0, sticky ="w", padx = 10, pady =2)
    websitelabel.grid(row=2, column=0, sticky ="w", padx = 10, pady =2)
    emaillabel.grid(row=4, column=0, sticky ="w", padx = 10, pady =2)
    passwordlabel.grid(row=6, column= 0, sticky ="w", padx = 10, pady =2)

    commands_frame = LabelFrame(pmoptions_frame, text="Commands")
    commands_frame.configure(height = 350, width = 225)
    commands_frame.grid_propagate(FALSE)
    commands_frame.grid(row = 1, column = 0, padx = 10, pady = 10, sticky = W)

    updaterecordbutton = Button(commands_frame, text ="Update Record", command = updaterecord)
    addrecordbutton = Button(commands_frame, text = "Add Record", command = addrecord)
    clearrecordbutton = Button(commands_frame, text = "Clear Entry Boxes", command = clearentry)
    deleterecordbutton = Button(commands_frame, text = "Delete Record", command  = deleterow)
    deletemanyrecordsbutton = Button(commands_frame, text = "Delete Many Records", command = deletemanyrecords)
    moverowup = Button(commands_frame, text = "Move Record Up", command = moveup)
    moverowdown = Button(commands_frame, text = "Move Record Down", command = movedown)

    updaterecordbutton.grid(row = 0, column = 0, padx = 10, pady = 10, sticky = W)
    addrecordbutton.grid(row = 1, column = 0, padx = 10, pady = 10, sticky = W)
    clearrecordbutton.grid(row = 2, column = 0, padx = 10, pady = 10, sticky = W)
    deleterecordbutton.grid(row = 3, column = 0, padx = 10, pady = 10, sticky = W)
    deletemanyrecordsbutton.grid(row = 4, column = 0, padx = 10, pady = 10, sticky = W)
    moverowup.grid(row = 5, column = 0, padx = 10, pady = 10, sticky = W)
    moverowdown .grid(row = 6, column = 0, padx = 10, pady = 10, sticky = W)

    pmmy_tree.bind("<ButtonRelease-1>", selectrecord)

    # Display pgframe within Mainframe
    pmframe.grid(row=0, column=0, sticky="nsew")
    
    

HomeButton = Button(root, text = "Home", pady = 20, command = homepage)
HomeButton.grid(row = 0, column = 0, sticky = 'nesw')

HelpButton = Button(root, text = "Help?", padx = 35, command = helppage)
HelpButton.grid(row = 0, column = 1, sticky = 'nesw')

Options = LabelFrame(root, text = "Options Menu", padx = 80, pady = 173)
Options.grid(row = 1, column = 0, sticky = W)

PasswordManagerButton = Button(Options, text = "Password Manager", padx = 50, pady  =50, command = pmpage)
PasswordManagerButton.grid(row = 1, column = 0)

spacer1 = Label(Options, text="")
spacer1.config(font=('Helvetica bold', 60))
spacer1.grid(row=2, column=0)

PasswordGeneratorButton = Button(Options, text = "Password Generator", padx = 50, pady =50, command = pgpage)
PasswordGeneratorButton.grid(row = 3, column = 0)

Mainframe = tk.Frame(root, highlightbackground='grey', highlightthickness=2)
Mainframe.grid_propagate(False)
Mainframe.configure(height = 700, width = 1125)
Mainframe.place(relx = 0.255, rely = 0.085)

homepage()

root.mainloop()