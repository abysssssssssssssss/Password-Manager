import random
import string

def generator(wordcount, numbercount, symbolcount, has_favoriteword, favoriteword):
    file = open('CommonEnglishWords.txt', 'r')
    f = file.readlines()

    wordlist = []
    for line in f:
        wordlist.append(line.strip())

    digits = string.digits
    symbols = string.punctuation

    global temppassword
    temppassword = ""

    if has_favoriteword:
        temppassword += favoriteword

    for _ in range(wordcount):
        temppassword += random.choice(wordlist)

    for _ in range(numbercount):
        temppassword += random.choice(digits)

    for _ in range(symbolcount):
        temppassword += random.choice(symbols)
    

    return temppassword

