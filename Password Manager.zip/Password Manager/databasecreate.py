import sqlite3

def createpasswordlistdatabase():
    conn = sqlite3.connect('passwordlist.db')

    c = conn.cursor()

    c.execute('''CREATE TABLE if not exists passwordlist(
            website text,
            email text,
            password text
            )''')

    conn.commit()

    conn.close()
