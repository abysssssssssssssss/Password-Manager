import main

def homepage():
    homepage = tk.Frame(Mainframe)

    createpasswordlistdatabase()
    creategeneratedpasswordlistdatabase()

    file = open('homepagetext.txt', 'r', encoding="UTF8").read()

    homepagetitle = Label(homepage, text = "Memento")
    homepagetitle.config(font = ('Arial',  20))
    homepagetext = Label(homepage, text = file, justify="left", wraplength = 1000)

    homepagetitle.grid(row = 0, column = 0, padx=(20, 0), pady=(15, 0), sticky = W)
    homepagetext.grid(row = 1, column = 0, padx=(20, 0), pady=(15, 0), sticky = W)

    homepage.grid(row = 0, column = 0, sticky="nsew")